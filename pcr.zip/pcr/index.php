<!DOCTYPE html>
<html>
<title>PCRM</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
<style>
body,h1 {font-family: "Raleway", sans-serif}
body, html {height: 100%}
.bgimg {
  background-image: url('IMG/Engineering11.jpg');
  min-height: 100%;
  background-position: center;
  background-size: cover;
}
.column {
  float: right;
  width: 1500px;
  height: 200px;
  position:center;
  padding: 15px;
}
.card{
	position:center;
}
</style>
<body>
<!-- Sidebar -->
<nav class="w3-sidebar w3-animate-top w3-xxlarge" style="display:none;padding-top:150px;background:#6B7A8F" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-black w3-xxlarge w3-padding w3-display-topright" style="padding:6px 24px">
    <i class="fa fa-remove"></i>
  </a>
 
  <div class="row" style="border:5px">
	  <div class="column">
			<div class="card">
				<div class="card-body">
					<div style="color:black;text-align:center">NEWS</div>

<p><b>Tip:</b> Resize the browser window to see how the value "justify" works.</p>
  
  
  
  
  
  
				</div>
  
  
  
  
  
  
  
  
  </div>
  </div>
  <div class="column">
  <div class="w3-bar-block w3-center">
    <a href="INT/login.php" class="w3-bar-item w3-button "style="color:black">SIGN IN</a>
  </div>
  
  
  
  </div>
</div>
 
  
</nav>


<!-- Header -->

<div class="bgimg w3-display-container w3-animate-opacity w3-text-white">
	
			<div class="w3-display-topleft w3-padding-large w3-xlarge">
				Logo
			</div>
			<div class="w3-opacity">
				<span class="w3-button w3-xxlarge w3-white w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></span> 
				<div class="w3-clear"></div>

			</div>
			<div class="w3-display-middle w3-padding-large w3-border w3-wide w3-text-light-grey w3-center">
				<h1 class="w3-hide-medium w3-hide-small w3-xxxlarge">PCRM System</h1>
				<h3 class="w3-hide-medium w3-hide-small">Process Change Report Managements System</h3>
			</div>
			<div class="w3-display-bottomleft w3-padding-large"></div>
	
</div>

</body>
<script>
// Toggle grid padding
function myFunction() {
  var x = document.getElementById("myGrid");
  if (x.className === "w3-row") {
    x.className = "w3-row-padding";
  } else { 
    x.className = x.className.replace("w3-row-padding", "w3-row");
  }
}

// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.width = "100%";
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
</html>