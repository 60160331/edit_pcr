<?php
session_start();
include "../ENG/connectpcr.php";
include "../ENG/connectdbmc.php";


?>

<!DOCTYPE html>
<html lang="en">

	<head>
	

	
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
	   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

	
	
  <link href="assets/css/fresh-bootstrap-table.css" rel="stylesheet" />

  <!-- Fonts and icons -->
  <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/demo_1/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png">
  </head>

	
  <body>
  
<?php
header('Content-Type: text/html; charset=utf-8');

$File_Type_Allow = array('application/pdf'); //กำหนดประเภทของไฟล์ว่าไฟล์ประเภทใดบ้างที่อนุญาตให้ upload มาที่ Server
$Upload_Dir = "fileupload/plan";
$Max_File_Size = 200000000; //กำหนดขนาดไฟล์ที่ ใหญ่ที่สุดที่อนุญาตให้ upload มาที่ Server มีหน่วยเป็น byte

function validate_form($file_input, $file_size, $file_type)
{ //เป็น function ที่เอาไว้ตรวจสอบว่าไฟล์ที่ผู้ใช้ upload ตรงตามเงื่อนไขหรือเปล่า
    global $Max_File_Size,$File_Type_Allow;
    if ($file_input == "none") {
        $error = "ไม่มี file ให้ Upload";
    } elseif ($file_size > $Max_File_Size) {
        $error = "ขนาดไฟล์ใหญ่กว่า $Max_File_Size ไบต์";
    } elseif (!check_type($file_type, $File_Type_Allow)) {
        $error = "ไฟล์ประเภทนี้ ไม่อนุญาตให้ Upload <strong>อัพโหลดได้เฉพาะไฟล์นามสกุล PDF</strong>";
    } else {
        $error = false;
    }

    return $error;
}

function check_type($type_check)
{ //เป็น ฟังก์ชัน ที่ตรวจสอบว่า ไฟล์ที่ upload อยู่ในประเภทที่อนุญาตหรือเปล่า
    global $File_Type_Allow;
    for ($i=0;$i<count($File_Type_Allow);$i++) {
        if ($File_Type_Allow[$i] == $type_check) {
            return true;
        }
    }
    return false;
}

if ($_FILES['file']['error']) {
    die($_FILES["file"]["error"]);
}

if ($_FILES['file']) {
    $error_msg = validate_form($_FILES['file'], $_FILES['file']["size"], $_FILES['file']["type"]); // ตรวจดูว่า ไฟล์ที่ upload ตรงตามเงื่อนไขหรือเปล่า
    if ($error_msg) {
        die($error_msg);
    } else {
        if (copy($_FILES['file']['tmp_name'], $Upload_Dir."/".$_FILES['file']['name'])) { //ทำการ copy ไฟล์มาที่ Server
            echo "ไฟล์ Upload เรียบร้อย";
        } else {
            die("ไฟล์ Upload มีปัญหา ".$_FILES["file"]["error"]);
        }
    }
}


?>



</body>
  
</html>