<?php
date_default_timezone_set('asia/bangkok');
session_start();
include "../ENG/connectpcr.php";
include "../ENG/connectdbmc.php";
include "../ENG/function_form.php";
$sql = "SELECT *,SUBSTRING(fm_create_date,1,10) as created_date FROM `pcr_form` LEFT JOIN pcr_annual_plan on pcr_form.fm_anp_id = pcr_annual_plan.anp_anp_number LEFT JOIN pcr_section_anp on pcr_annual_plan.`anp_sec_id` = pcr_section_anp.sec_id   
LEFT JOIN pcr_change_type on pcr_annual_plan.`anp_ct_id` = pcr_change_type.ct_id LEFT JOIN pcr_change_point on pcr_annual_plan.anp_cp_id = pcr_change_point.cp_id 
LEFT JOIN pcr_product ON pcr_annual_plan.anp_pro_id = pcr_product.pro_id LEFT JOIN pcr_rank ON pcr_annual_plan.anp_rk_id = pcr_rank.rk_id WHERE fm_pcr_number = '".$_REQUEST["pcr_number"]."'";
 $query = mysqli_query($conn, $sql);
 $pcr = mysqli_fetch_array($query);


 $sqlfileupload = "SELECT fp.fup_name AS fup_name FROM pcr_file_upload as fp INNER JOIN pcr_form as fm on fp.fup_fm_id = fm.fm_id INNER JOIN pcr_file_type AS tp ON fp.fup_ft_id = tp.ft_id WHERE tp.ft_id = 1 AND fm.fm_pcr_number='".$_REQUEST["pcr_number"]."'";
 $fp = $conn->query($sqlfileupload);
 $file = $fp->fetch_assoc();

 $sqlatt ="SELECT att.att_daily_check AS att_daily_check,att.att_other AS att_other,att.att_machine_spec AS att_machine_spec ,att.att_pfmea AS att_pfmea,att.att_qa_network AS att_qa_network ,att.att_control_plan AS att_control_plan ,att.att_wi AS att_wi  FROM pcr_form AS fm LEFT JOIN pcr_attach_doc AS att ON fm.fm_id = att.att_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."'";
 $att= $conn->query($sqlatt);
 $attdoc = $att->fetch_assoc();

//implement plan start
 $implement1 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 1";
 $imple1 = $conn->query($implement1);
 $im1 = $imple1->fetch_assoc();

 $implement2 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 2";
 $imple2 = $conn->query($implement2);
 $im2 = $imple2->fetch_assoc();

 $implement3 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 3";
 $imple3 = $conn->query($implement3);
 $im3 = $imple3->fetch_assoc();

 $implement4 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 4";
 $imple4 = $conn->query($implement4);
 $im4 = $imple4->fetch_assoc();
 
 $implement5 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 5";
 $imple5 = $conn->query($implement5);
 $im5 = $imple5->fetch_assoc();
 
 $implement6 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 6";
 $imple6 = $conn->query($implement6);
 $im6 = $imple6->fetch_assoc();
 
 $implement7 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 7";
 $imple7 = $conn->query($implement7);
 $im7 = $imple7->fetch_assoc();
 
 $implement8 = "SELECT  SUBSTRING(mf.mf_date_plan,1,10) AS dateplan, SUBSTRING(mf.mf_date_result,1,10) AS dateresult FROM pcr_implement_form AS mf INNER JOIN pcr_form AS fm ON mf.mf_fm_id = fm.fm_id INNER JOIN pcr_implement AS im ON mf.mf_im_id = im.im_id WHERE fm.fm_pcr_number = '".$_REQUEST["pcr_number"]."' AND mf.mf_im_id = 8";
 $imple8 = $conn->query($implement8);
 $im8 = $imple8->fetch_assoc();
 //implement plan end

 //sc point start
 $sqlsc1 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 1" ;
 $querypri1 = $conn->query($sqlsc1);
 $s_circle1 = $querypri1->fetch_assoc();

 $sqlsc2 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 2" ;
 $querypri2 = $conn->query($sqlsc2);
 $s_circle2 = $querypri2->fetch_assoc();

 $sqlsc3 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 3" ;
 $querypri3 = $conn->query($sqlsc3);
 $s_triangle = $querypri3->fetch_assoc();

 $sqlsc4 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 4" ;
 $querypri4 = $conn->query($sqlsc4);
 $f_circle1 = $querypri4->fetch_assoc();

 $sqlsc5 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 5" ;
 $querypri5 = $conn->query($sqlsc5);
 $f_circle2 = $querypri5->fetch_assoc();

 $sqlsc6 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 6" ;
 $querypri6 = $conn->query($sqlsc6);
 $f_triangle = $querypri6->fetch_assoc();

 $sqlsc7 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 7" ;
 $querypri7 = $conn->query($sqlsc7);
 $e_circle1 = $querypri7->fetch_assoc();
 
 $sqlsc8 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 8" ;
 $querypri8 = $conn->query($sqlsc8);
 $e_circle2 = $querypri8->fetch_assoc();

 $sqlsc9 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 9" ;
 $querypri9 = $conn->query($sqlsc9);
 $e_triangle = $querypri9->fetch_assoc();

 $sqlsc10 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 10" ;
 $querypri10 = $conn->query($sqlsc10);
 $c_circle1 = $querypri10->fetch_assoc();
 
 $sqlsc11 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 11" ;
 $querypri11 = $conn->query($sqlsc11);
 $c_circle2 = $querypri11->fetch_assoc();
 
 $sqlsc12 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 12" ;
 $querypri12 = $conn->query($sqlsc12);
 $c_triangle = $querypri12->fetch_assoc();
 
 $sqlsc13 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 13" ;
 $querypri13 = $conn->query($sqlsc13);
 $dk = $querypri13->fetch_assoc();
 
 $sqlsc14 = "SELECT pri.pri_id AS pri_id ,pri.pri_name AS pri_name FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_REQUEST["pcr_number"]."' AND pri.pri_id = 14" ;
 $querypri14 = $conn->query($sqlsc14);
 $ln = $querypri14->fetch_assoc();
 //sc end
?>

<!DOCTYPE html>
<html lang="en">

<head>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
		<link href="assets/css/fresh-bootstrap-table.css" rel="stylesheet" />

		<!-- Fonts and icons -->
		<link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet">
		<link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">


		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=11; IE=EDGE; Chrome=1" />
		<!-- plugins:css -->
		<link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
		<link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
		<!-- endinject -->
		<!-- Plugin css for this page -->
		<!-- End plugin css for this page -->
		<!-- inject:css -->
		<!-- endinject -->
		<!-- Layout styles -->
		<link rel="stylesheet" href="../assets/css/demo_1/style.css">
		<!-- End layout styles -->
		<link rel="shortcut icon" href="../assets/images/favicon.png">
		
		<!-- Time picker -->
		<script type="text/javascript" src="../assets/timepicker/moment.js"></script>
		<script type="text/javascript" src="../assets/timepicker/transition.js"></script>
		<script type="text/javascript" src="../assets/timepicker/collapse.js"></script>
		<script type="text/javascript" src="../assets/timepicker/bootstrap-datetimepicker.min.js"></script>
		<!-- Time picker -->
		
		<!-- datepicker -->
		<link rel="stylesheet" media="all" type="text/css" href="../assets/jquerydatepicker/jquery-ui.css" />
		<link rel="stylesheet" media="all" type="text/css" href="../assets/jquerydatepicker/jquery-ui-timepicker-addon.css" />
		<script type="text/javascript" src="../assets/jquerydatepicker/jquery-1.10.2.min.js"></script>
		<script type="text/javascript" src="../assets/jquerydatepicker/jquery-ui.min.js"></script>
		<script type="text/javascript" src="../assets/jquerydatepicker/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="../assets/jquerydatepicker/jquery-ui-sliderAccess.js"></script>
		<!-- datepicker -->	
</head>
  <script>
$(document).ready(function() {
    $('#example').DataTable();
	
});

$(function(){
	$("#pcr_plan_sub_plan,#pcr_plan_sub_actual,#plan_review_plan,#plan_review_actual,#pro_preparation_plan,#pro_preparation_actual,#product_evaluation_plan,#product_evaluation_result,#revise_doc_stadart_plan,#revise_doc_stadart_result,#six_report_plan,#six_report_result,#pcr_result_sum_plan,#pcr_result_sum_result,#product_start_date_plan,#product_start_date_result").datepicker({
		dateFormat: 'yy-mm-dd',
		minDate : 0
	});
});


  </script>
 
 <body>
  <div class="container-scroller">
  
  <?php
    include("Navbar_pcr.php")?>
	<div class="container-fluid page-body-wrapper">
	<?php
    include("header_creator.php")?>
		<!--space header-->
	    <div class="main-panel">
          <div class="content-wrapper">

			<!--space header-->
		
		
			<div class="row">

			<div class="col-12 grid-margin stretch-card">
            
			<div class="card">


				<div class="card-header headC">
					<center style="color:white;"><label><b>Edit PCR</b><label></center>
				</div>

				  
	<fieldset>
        <!-- <legend class="text-white"  style="background-color:#b66dff"><p style="text-align: center;"><b>Process Change Report Form</b></p></legend> -->
			
		  <div class="card-body">  	
        
<!-- Start form section 1 -->      
					<div class="card-header">
		<form accept="application/pdf" action="upload.php" method="post" enctype="multipart/form-data">		
	<!-- <form id="pcr" name="pcr" action="../ENG/update_pcr_form.php" method="post" >
	 -->
					<!--<h4><b>Data My Creater :</b></h4>-->
					
						<div class="columns">
							<div class="item" style="text-align:right;" >
									<label for="pcr_number"><b>No :</b></label>
									<input id="pcr_number" type="text" name="pcr_number" class="data-attachments-input"   placeholder="Number PCR" value="<?php echo $_REQUEST["pcr_number"] ;?>" readonly />
							
							</div>
							<div class="item" style="text-align:right;">
									<label for="create_date"><b>Create Date :</b></label>
									<input id="create_date" type="text" name="create_date" value="<?php  echo $pcr["created_date"]?>" class="data-attachments-input"  
									placeholder="Create Date " disabled/>		
							</div>
						</div>	
							
						<div class="columns">	
							<div class="item" style="text-align:right;" >
									<label for="registant"><b>Registant :</b></label>
									<input id="registant"  type="text" name="registant" class="data-attachments-input" value= "<?php echo $_SESSION["empname_pcr"]." ".$_SESSION["emplast_pcr"][0]."." ?>" placeholder="Registant" disabled/>
							</div>
							
							<div class="item" style="text-align:right;">
									<label for="create_dapartment"><b>Dept / Sec :</b></label>
									<input id="create_date" type="text" value="<?php echo $_SESSION["dept_pcr"]." / ".$_SESSION["sct_pcr"]?>" name="create_date" class="data-attachments-input" placeholder="Department / Section  "  disabled/>
							</div>
							
						</div>
							

					</div>	
<!-- end form section 1 -->					
          <br>
          


<!-- Start form section 2 -->          
				<div class="card-header">
				
						<div class="row">
								<div class="col-md-12" style="height:40px;">
										<div class="card" style="height:70%;">  
											  <div class="form-group row">
													<div class="col-sm-4">
														  <div class="form-check" style="text-align:right;">
																<label class="form-check-label">
																  <label ><b>PCR type :</b></label> 
																  </label>
														  </div>
													</div>
													<?php if ($pcr["fm_pcr_leadtime"] == "normal") {?>
													<div class="col-sm-2">
														  <div class="form-check">
																<label class="form-check-label" style="color:green;">
																  <input  checked type="radio" class="form-check-input" name="normal_urgent" id="Normal" value="normal"> Normal </label>
														  </div>
													</div>
													<div class="col-sm-2">
														  <div class="form-check">
																<label class="form-check-label" style="color:red;">
																  <input type="radio" class="form-check-input" name="normal_urgent" id="Urgent" value="urgent">
																  Urgent</label>
														  </div>
													</div>
													
													<?php } elseif ($pcr["fm_pcr_leadtime"] == 0) { ?>
													
														<div class="col-sm-2">
														  <div class="form-check">
																<label class="form-check-label" style="color:green;">
																  <input  type="radio" class="form-check-input" name="normal_urgent" id="Normal" value="normal"> Normal </label>
														  </div>
													</div>
													<div class="col-sm-2">
														  <div class="form-check">
																<label class="form-check-label" style="color:red;">
																  <input checked type="radio" class="form-check-input" name="normal_urgent" id="Urgent" value="urgent">
																  Urgent</label>
														  </div>
													</div>
													<?php }?>
											  </div>
										</div>											  
								</div>
						</div>	
							<div class="row">
								<div class="col-md-12" style="height:40px;">
											<div class="form-group row">
													<div class="col-sm-4">
															<div class="form-check" style="text-align:right;">
																	<label class="form-check-label" >
																	 <b>Part test flow out :</b>
																	  </label>
															</div>
													</div>
													<?php if ($pcr["fm_flowout"] == 1) {?>
														<div class="col-sm-2">
														<div class="form-check">
															<label class="form-check-label">
															
															  <input checked type="radio" class="form-check-input"  name="Part_test_flow_out" id="" value="1"> Yes </label>
														</div>
												</div>
												<div class="col-sm-2">
														<div class="form-check">
															<label class="form-check-label">
															  <input type="radio" class="form-check-input" name="Part_test_flow_out" id="" value="0">No</label>
														</div>
												</div>
													
													<?php } elseif ($pcr["fm_flowout"] == 0) { ?>
													
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																
																  <input type="radio" class="form-check-input"  name="Part_test_flow_out" id="" value="1"> Yes </label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked  type="radio" class="form-check-input" name="Part_test_flow_out" id="" value="0">No</label>
															</div>
													</div>
													<?php } ?>
											</div>										  
								</div>
							</div>	
					<div class="card" style="height:50%;"> 
							<div class="row">
									<div class="col-md-12" style="height:40px;">
									          <div class="form-group row">
													<div class="col-sm-4">
															<div class="form-check" style="text-align:right;">
																	<label class="form-check-label">
																	 <b>Risk and Effect analysis</b>
																	</label>
															</div>
													</div>
												
											  </div>			
									</div>
							  
							  
									<div class="col-md-12" style="height:40px;">
											  <div class="form-group row">
													<div class="col-sm-4">
															<div class="form-check" style="text-align:right;">
																	<label class="form-check-label">
																	  Quality :
																	</label>
															</div>
													</div>
													<?php if ($pcr["fm_quality"] == 1) {?>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="quality" id="" value="1">Yes</label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check" >
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="quality" id="" value="0">No</label>
															</div>
													</div>
													<?php } elseif ($pcr["fm_quality"] == 0) { ?>
														<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="quality" id="" value="1">Yes</label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check" >
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="quality" id="" value="0">No</label>
															</div>
													</div>
													<?php } ?>
											  </div>										  
									</div>
									
									<div class="col-md-12" style="height:40px;">
											  <div class="form-group row">
													<div class="col-sm-4">
															<div class="form-check" style="text-align:right;">
																	<label class="form-check-label" >
																	 Safety :
																	</label>
															</div>
													</div>
													<?php if ($pcr["fm_safety"] == 1) {?>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="safety" id="" value="1" > Yes </label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="safety" id="" value="0" >No</label>
															</div>
													</div>
													<?php } elseif ($pcr["fm_safety"] == 0) { ?>
														<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="safety" id="" value="1" > Yes </label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="safety" id="" value="0" >No</label>
															</div>
													</div>
													<?php } ?>
											  </div>										  
									</div>
									<div class="col-md-12" style="height:40px;">
											  <div class="form-group row">
													<div class="col-sm-4">
															<div class="form-check" style="text-align:right;">
																	<label class="form-check-label" >
																	Delivery :
																	  </label>
															</div>
													</div>
													<?php if ($pcr["fm_delivery"] == 1) {?>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="delivery" id="" value="1" > Yes </label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="delivery" id="" value="0" >No</label>
															</div>
													</div>
													<?php } elseif ($pcr["fm_delivery"] == 0) { ?>
														<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="delivery" id="" value="1" > Yes </label>
															</div>
													</div>
													<div class="col-sm-2">
															<div class="form-check">
																<label class="form-check-label">
																  <input checked type="radio" class="form-check-input" name="delivery" id="" value="0" >No</label>
															</div>
													</div>
													<?php } ?>
											  </div>										  
									</div>
									
									
							</div>			
								
								
					</div>		
					<br>					
	 
								 
				</div>	

						
				<br>		
					
			<div class="card-header">
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->				
						<div class="columns">
							<div class="item" style="text-align:right;">
									<label for="addition_item"><b>Addition item:</b></label>
									<?php
                                    $add_item="";
                                    if ($pcr["anp_add_item"] == 1) {
                                        $add_item ="Yes";
                                    } else {
                                        $add_item ="No";
                                    }?>
									<input value ="<?php echo $add_item?>"id="addition_item" type="text" name="addition_item" class="data-attachments-input" placeholder="Addition item" disabled/>
						
							</div>
							<div class="item" style="text-align:right;">
									<label for="anuual_Plan_No"><b>Anuual Plan:<label style="color:red;">*</label></b></label>
									<input value ="<?php echo $pcr["anp_anp_number"]?>" id="anuual_Plan_No"   type="text" name="anuual_Plan_No"  class="data-attachments-input" placeholder="Anuual plan number" disabled />
									
							</div>				
						</div>
						<div class="columns">
							<div class=" item col-md-11" style="text-align:right;" >
										<label for=""><b>Title :</b><span></span>
										<input value ="<?php echo $pcr["anp_title"]?>"id="title_pcr" style="width:605px;"  type="text" name="title_pcr"  class="data-attachments-input" placeholder="Title" disabled > </label>
							</div>
						</div>
	<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->				
						<div class="columns">	
							<div class="item" style="text-align:right;">
									<label for="change_type"><b>Change type :</b><span></span></label>
									<input value ="<?php echo $pcr["ct_name"]?>"id="change_type" type="text" name="change_type"  class="data-attachments-input" placeholder="Change type" disabled/>
							</div>
							<div class="item" style="text-align:right;">
									<label for="rank"><b>Rank :</b><span></span></label>
									<input value ="<?php echo $pcr["rk_name"]?>"id="rank" type="text" name="rank"  class="data-attachments-input" placeholder="Rank" disabled/>
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->				
							<div class="item" style="text-align:right;">
									<label for="customer_submission "><b>Customer sub :</b><span></span></label>
									<input value ="<?php echo $pcr["anp_cus_sub"]?>"id="customer_submission" type="text" name="customer_submission"  class="data-attachments-input"  disabled/>
							</div>
							<?php
                                    $plan_review="";
                                    if ($pcr["anp_plan_review"] == 1) {
                                        $plan_review ="Yes";
                                    } else {
                                        $plan_review ="No";
                                    }?>
							<div class="item" style="text-align:right;">
									<label for="planning_review"><b>Plan review:</b><span></span></label>
									<input id="planning_review" type="text" name="planning_review" value ="<?php echo $plan_review?>"   class="data-attachments-input"  placeholder="Planning review" disabled/>
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->
							<div class="item" style="text-align:right;">
									<label for="product"><b>Product :</b><span></span></label>
									<input id="product" type="text"value ="<?php echo $pcr["pro_name"]?>" name="product"   class="data-attachments-input" placeholder="Product"/disabled>
							</div>
							<div class="item" style="text-align:right;">
									<label for="part_name"><b>Part name :</b><span></span></label>
									<input id="part_name" type="text" name="part_name" value ="<?php echo $pcr["anp_part_name"]?>" class="data-attachments-input" placeholder="Part name"/disabled>
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->
							<div class="item" style="text-align:right;">
									<label for="part_number" style="font-size:14px;"><b>Part number :</b><span></span></label>
									<input id="part_number" type="text" name="part_number"  value ="<?php echo $pcr["fm_part_number"]?>"class="data-attachments-input" placeholder="Part number"/>
							</div>
							<div class="item" style="text-align:right;">
									<label for="change_point" style="font-size:14px;"><b>Change point :</b><span></span></label>
									<input id="change_point" type="text" name="change_point"  value ="<?php echo $pcr["ct_name"]?>"  class="data-attachments-input" placeholder="Change point"/disabled>
							</div>
						
						</div>
				
					<br>
					<label style="font-size:14px;"><b>Priority Management Category :</b></label>
					<div class="row">
					
						<div class="col-md-2" style="text-align:right">
							  <div class="form-group">	
							  </div>
                        </div>
						
                           
						
						<div class="col-md-2" style="text-align:right">
							  <div class="form-group">
							 
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"  class="form-check-input" name="sc[]" value="1" <?php echo($s_circle1['pri_name']!= null ? 'checked' : '');?>>   
										</label>
										<img src="../assets/images/simbol/S2-removebg.png" class="imageC2" >
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"   class="form-check-input" name="sc[]" value="2"<?php echo($s_circle2['pri_name']!= null ? 'checked' : '');?>>
										</label>
										<img src="../assets/images/simbol/S3-removebg.png" class="imageC2" >
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"  class="form-check-input" name="sc[]" value="3"<?php echo($s_triangle['pri_name']!= null ? 'checked' : '');?>>
										</label>
										<img src="../assets/images/simbol/S1-removebg.png" class="imageC2" >
									</div>
							  </div>
                        </div>
						<div class="col-md-2">
							  <div class="form-group">
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"  class="form-check-input" name="sc[]" value="4"<?php echo($f_circle1['pri_name']!= null ? 'checked' : '');?>>
										</label> 
										</label>
										<img src="../assets/images/simbol/F2-removebg.png" class="imageC2" >
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"   class="form-check-input" name="sc[]" value="5"<?php echo($f_circle2['pri_name']!= null ? 'checked' : '');?>>
										</label>
										</label>
										<img src="../assets/images/simbol/F3-removebg.png" class="imageC2" >
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"  class="form-check-input" name="sc[]" value="6"<?php echo($f_triangle['pri_name']!= null ? 'checked' : '');?>>
										</label>  
										</label>
										<img src="../assets/images/simbol/F1-removebg.png" class="imageC2" >
									</div>
							 </div>
                        </div>
						<div class="col-md-2">
							  <div class="form-group">
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input  type="checkbox" class="form-check-input" name="sc[]" value="7"<?php echo($e_circle1['pri_name']!= null ? 'checked' : '');?>>
										</label> 
										</label>
										<img src="../assets/images/simbol/E2-removebg.png" class="imageC2">
									</div>
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input  type="checkbox" class="form-check-input" name="sc[]" value="8"<?php echo($e_circle2['pri_name']!= null ? 'checked' : '');?>>
										</label>
										</label>
										<img src="../assets/images/simbol/E3-removebg.png" class="imageC2"  >
									</div>
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input   type="checkbox"  class="form-check-input" name="sc[]" value="9"<?php echo($e_triangle['pri_name']!= null ? 'checked' : '');?>>  
										</label>
										<img src="../assets/images/simbol/E1-removebg.png" class="imageC2"  >
									</div>
							  </div>
                        </div>
						<div class="col-md-2">
							  <div class="form-group">
								  
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input type="checkbox"  class="form-check-input" name="sc[]" value="10"<?php echo($c_circle1['pri_name']!= null ? 'checked' : '');?>>  
										</label>
										<img src="../assets/images/simbol/C2-removebg.png" class="imageC2"  >
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input  type="checkbox" class="form-check-input" name="sc[]" value="11"<?php echo($c_circle2['pri_name']!= null ? 'checked' : '');?>>
										</label>
										<img src="../assets/images/simbol/C3-removebg.png" class="imageC2"  >
									</div> 
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input  type="checkbox"  class="form-check-input" name="sc[]" value="12"<?php echo($c_triangle['pri_name']!= null ? 'checked' : '');?>>
										</label>
										<img src="../assets/images/simbol/C4-removebg-preview.png" class="imageC2">
									</div> 							
							  </div>
                        </div>
						<div class="col-md-2">
							  <div class="form-group">
								  <div class="form-check col-sm-6">
										<label class="form-check-label">
										<input  type="checkbox" class="form-check-input"></label>
										<img src="../assets/images/simbol/DK-removebg-preview.png" class="imageC2" name="Dk" value="13"<?php echo($dk['pri_name']!= null ? 'checked' : '');?>>
									</div>
									
									<div class="form-check col-sm-6">
									  <label class="form-check-label">
										<input  type="checkbox" class="form-check-input">  
										</label>
										<img src="../assets/images/simbol/In-removebg-preview.png" class="imageC2" name="In" value="14"<?php echo($ln['pri_name']!= null ? 'checked' : '');?>>
									</div>
 							
							  </div>
                        </div>
						
                    </div>
            </div>
		
<!-- end form section 2 -->

<br>

<!-- Start form section 3  // Upload file-->
        
			<div class="card-header">
              <label style="font-size:14px;"><b>Details of Process Change</b></label>
					
					<div class="form-group" >
					<br>
						<label>File upload plan <label style="color:red;">( Maximum file upload size 9.5 MB )</label></label>
						<input type="file" name="img"  class="file-upload-default">
						<div class="input-group col-xs-12">
						
							  <input  style ="overflow:hidden;" name = "file" value ="<?php echo $file["fup_name"]?>" type ="file" class="form-control file-upload-info"  placeholder="Upload File plan">
							  <span class="input-group-append">
									<label for ="file" class="file-upload-browse btn " type="button" name="uplode_file_plan" style ="background-color:#124373; border-color:#124373; color:white;"  >Upload</label>
							  </span>
						 
							
						</div>
						<br>
						<br>
						
					</div>
					
				
			</div>	
<!-- end form section 3 -->    

<br>

<!-- Start form section 4  // Date and time issue---->
            


				
                
               
						
					
            <div class="card-header">
                     <label style="font-size: 14px;"><b>Implementation plan</b></label> <br> <br>
						  <span style="font-size: 14px;">1) PCR plan submission </span>
						  <br>
						  
                        <div class="columns">
                                <div class="item"  style="text-align:right;">     					
                                  <label for="pcr_plan_sub_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im1["dateplan"]?>"id="pcr_plan_sub_plan" type="text"  name="pcr_plan_sub_plan"  class="data-attachments-input"/>      
                                </div>
                                <div class="item"  style="text-align:right;">
                                    <label for="pcr_plan_sub_actual"><span>Actual :</span></label>
                                    <input value =""id="pcr_plan_sub_actual" type="text" disabled name="pcr_plan_sub_actual"    class="data-attachments-input" />
                                </div>
                        </div> 
<br>						
						<span style="font-size: 14px;">2) Planning review </span>
                        <div class="columns">
                                <div class="item"  style="text-align:right;">     					
                                  <label for="plan_review_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im2["dateplan"]?>"id="plan_review_plan" type="text" name="plan_review_plan" class="data-attachments-input"/>      
                                </div>
                                
                                <div class="item"  style="text-align:right;">
                                    <label for="plan_review_actual"><span>Actual :</span></label>
                                    <input value =""disabled id="plan_review_actual" type="text" name="plan_review_actual"  class="data-attachments-input" />
                                </div>
                        </div>  
<br>							
						<span  style="font-size: 14px;">3) Process preparation </span>
                        <div class="columns">
                                <div class="item" style="text-align:right;">     					
                                  <label for="pro_preparation_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im3["dateplan"]?>"id="pro_preparation_plan" type="text" name="pro_preparation_plan"  class="data-attachments-input"/>      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="pro_preparation_actual"><span>Actual :</span></label>
                                    <input value =""disabled id="pro_preparation_actual" type="text" name="pro_preparation_actual"  class="data-attachments-input" />
                                </div>
                        </div>  
<br>							
						<span style="font-size: 14px;">4) Product / Process evaluation </span>
                        <div class="columns">
                                <div class="item" style="text-align:right;">      					
                                  <label for="product_evaluation_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im4["dateplan"]?>"id="product_evaluation_plan" type="text" name="product_evaluation_plan"  class="data-attachments-input"/>      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="product_evaluation_result"><span>Actual :</span></label>
                                    <input value ="" disabled id="product_evaluation_result" type="text" name="product_evaluation_result"   class="data-attachments-input"/>
                                </div>
                        </div>  
<br>							
						<span style="font-size: 14px;">5) Revise document standard </span>
                        <div class="columns" style="text-align:right;">
                                <div class="item">     					
                                  <label for="revise_doc_stadart_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im5["dateplan"]?>"id="revise_doc_stadart_plan" type="text" name="revise_doc_stadart_plan" class="data-attachments-input"/>      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="revise_doc_stadart_result"><span>Actual :</span></label>
                                    <input value =""disabled id="revise_doc_stadart_result" type="text" name="revise_doc_stadart_result"  class="data-attachments-input"/>
                                </div>
                        </div>  
<br>							
						<span style="font-size: 14px;">6) 6 step / Quality report </span>
                        <div class="columns" style="text-align:right;">
                                <div class="item">     					
                                  <label for="six_report_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im6["dateplan"]?>"id="six_report_plan" type="text" name="six_report_plan" class="data-attachments-input" />      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="six_report_result"><span>Actual :</span></label>
                                    <input value =""id="six_report_result" disabled type="text" name="six_report_result"  class="data-attachments-input"/>
                                </div>
                        </div>  
<br>							
						<span style="font-size: 14px;">7) PCR result submission </span>
                        <div class="columns" >
                                <div class="item" style="text-align:right;">     					
                                  <label for="pcr_result_sum_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im7["dateplan"]?>"id="pcr_result_sum_plan" type="text" name="pcr_result_sum_plan"  class="data-attachments-input"/>      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="pcr_result_sum_result"><span>Actual :</span></label>
                                    <input value =""id="pcr_result_sum_result" disabled type="text" name="pcr_result_sum_result"  class="data-attachments-input"/>
                                </div>
                        </div> 
<br>	
						<span style="font-size: 14px;">8) Production Start Date </span>
                        <div class="columns">
                                <div class="item" style="text-align:right;">     					
                                  <label for="product_start_date_plan"><span>Plan :</span></label>
                                  <input value ="<?php echo $im8["dateplan"]?>"id="product_start_date_plan" type="text" name="product_start_date_plan" class="data-attachments-input" />      
                                </div>
                                
                                <div class="item" style="text-align:right;">
                                    <label for="product_start_date_result"><span>Actual :</span></label>
                                    <input value =""id="product_start_date_result" disabled type="text" name="product_start_date_result"  class="data-attachments-input"/>
                                </div>
                        </div>  					
					
                    </div>	
<!-- end form section 4 -->    

<br>

<!-- Start form section 5  // Data attachments -->
                    
                    <div class="card-header">
                          <label style="font-size: 14px;"><b>Data attachments</b></label>
						
						
                    <div class="row">
						<div class="col-md-1" >
						</div>
						
						<div class="col-md-5" >
                          <div class="form-group">
                            <div class="form-check col-md-8" >
								<label class="form-check-label" style="font-size: 14px;" >
									<input  id = "check_PFMEA" value ="1" type="checkbox" class="form-check-input" name="check_PFMEA" <?php echo($attdoc['att_pfmea']!= null ? 'checked' : '');?>> 
									1.PFMEA
								</label>
								<label style="font-size: 14px;">
									Doc No.<input value ="" disabled id="PFMEA" type="text" name="PFMEA"   style = "width: 70%;"  class="data-attachments-input" placeholder="Document No"/>
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label" style="font-size: 14px;">
									<input id="check_qa_network " value ="1" type="checkbox" class="form-check-input" name="check_qa_network"<?php echo($attdoc['att_qa_network']!=null ? 'checked' : '');?>> 
									2.QA Network
								</label>
								<label>
									 Doc No.<input value =""  disabled id="qa_network" type="text" name="qa_network"  style = "width: 70%;"   class="data-attachments-input" placeholder="Document No"/>
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label">
									<input value ="1" id ="check_control_plan"value ="1" type="checkbox" class="form-check-input" name="check_control_plan"<?php echo($attdoc['att_control_plan']!=null ? 'checked' : '');?> > 
									3.Control plan ,PCC
								</label>
								<label>
									Doc No.<input   disabled id="control_plan" type="text" name="control_plan"  style = "width: 70%;" class="data-attachments-input" placeholder="Document No" />
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label">
									<input id ="standardize"value ="1" type="checkbox" id ="standardize" class="form-check-input" name="standardize"<?php echo($attdoc['att_wi']!=null ? 'checked' : '');?>>  
									4.Standardize work , WI
								</label>
						
                            </div>
                          </div>
                        </div>
						
						
						<div class="col-md-6">
                          <div class="form-group">
                            <div class="form-check col-sm-8">
								<label class="form-check-label">
									<input id ="machine_sprci"value ="1" type="checkbox" class="form-check-input" name="machine_sprci" <?php echo($attdoc['att_machine_spec']!=null ? 'checked' : '');?>>
									5.Machine specification

								</label>
								<label>
									<input id="" type="hidden"  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							
							<div class="form-check col-sm-6">
								<label class="form-check-label">
									<input id ="daily_check"value ="1" type="checkbox" class="form-check-input" name="daily_check" <?php echo($attdoc['att_daily_check']!=null ? 'checked' : '');?>>  
									6.Daily check sheet
								</label>
								<label>
									<input id="" type="hidden"  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							<div class="form-check col-sm-6">
								<label class="form-check-label">
									<input id ="other"value ="1"type="checkbox" class="form-check-input" name="other" <?php echo($attdoc['att_other']!=null ? 'checked' : '');?>>  
									7.Other
								</label>
								<label>
									<input id="" type="hidden" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
                          </div>
                        </div>
	
             </div>
	 </div>	
<!-- end form section 5 -->    

<br>

<!-- Start form section 6  // Choice Approver -->
                    
                    <div class="card-header">
				<!--	<div class="row">  
							<div class="col-md-12">	<br>				
                                <label for="" style="font-size:14px;">Prepared : </label>   
								<input id="" type="text"  required style = "width: 40%;" name="prepared"  class="form-control" disabled />  
								       
							</div>
						</div> 
				-->
						<br>
						 <label style="font-size:14px;"><b>Approve of department</b></label>
						 
						<div class="row">  
							<div class="col-md-12">	
							<br>							
								  <label for="" style="font-size:14px;">Add amount of  Checker :	
									  <img src="../assets/images/plus_blue.png" class = "button_department" style="width: 4%; height: 4%;"/>		
								  </label>        
							</div>
						</div>
					
					<div class="row" id="add_boxinput_depart">
						<div class="col-md-12"> 
						<p for=""style="font-size:14px;"><u>Check Approver</u></p>	 
							<div class="form-group row" id="group_app_department">
							
						
								 
							</div>
						</div>
					</div>
					
					
					<p for=""style="font-size:14px;"><u>Final Approver</u></p>				
					<div class="row" id="add_boxinput_depart">
                        <div class="col-md-12">
                          <div class="form-group row" id="group_app_department">
						  
							 <div class="col-sm-4"> 
							 		<label for="appdepart_name" >Name :</label>
									<input list="list_Final" id="appdepart_Final" type="text" name="appdepart_final"    class="form-control" placeholder="Name"/>
									<datalist id="list_Final">
										<?php
                                            echo appdepart_Final($condbmc);
                                        ?>
									</datalist>
							 </div>
							 
							 <div class="col-sm-4"> 
							 		<label for="appdepart_Position">Position :<span></span></label>
                                    <input id="appdepart_Pos" type="text" name="appdepart_Pos"  class="form-control" placeholder="Position"/ disabled>
							 </div>
							 
                             <div class="col-sm-4"> 
							 		<label for="appdepart_department">Department :<span></span></label>
									<input id="appdepart_department" type="text" name="appdepart_department" class="form-control" placeholder="Department"/ disabled>
							 </div>
							 
						  </div>
						</div>
					</div>
					
						<label style="font-size:14px;"><b>Approve acknowledge department</b></label><br><br>
						<!--label style="font-size:14px;">Select Department :</label>
								<select id="Select_Department_pcr" type="text" name="Select_Department_pcr"  style="width:245px; height:32.6px;"  class="form-control" placeholder="Select Department"> 
									<option value="">Select Department</option>
									<?php
                                    $sqldept = "SELECT * FROM department WHERE Company_ID = '".$_SESSION["companyid_pcr"]."'";
                                    $querydept = $condbmc->query($sqldept);
                                    while ($rowdept = $querydept->fetch_assoc()) {
                                        ?>
									<option value="<?echo $rowdept["Dep_id"]?>"><?echo $rowdept["Dep_Name"]?></option>
									<?php
                                    }
                                    ?>
								</select--> 
					<br>
					<div class="row" style="height=40px;">
                        <div class="col-md-12" >
                          <div class="form-group row">

							 <div class="col-sm-4"> 
							 		<label for="" id="ackd_name">Name :</label>
									<input id="ackdepart_name_first" list="list_ackdepart" type="text" name="ackdepart_name_first"  class="form-control" placeholder="Name"/>
									<datalist id="list_ackdepart">
									 <?echo appdepart_acknowledge($condbmc);?>
									</datalist>
							</div>
							 
							 <div class="col-sm-4"> 
							 		<label for="ackdepart_Position_first">Position :</label>
                                    <input id="ackdepart_Position_first" type="text" name="ackdepart_Position_first"   class="form-control" placeholder="Position"/>
							 </div>
							 
							 <div class="col-sm-4"> 
							 		<label for="ackdepart_department">Department :</label>
									<input id="appdepart_Position" type="text" name="appdepart_Position" required  class="form-control" placeholder="Department"/>
							 </div>
						</div>	
						  </div>
				
						<!--div class="col-md-12">
						  <div class="form-group row">

							 <div class="col-sm-4"> 
							 		<label for="ackdepart_name" id="ackd_name">Name :</label>
									<input id="ackdepart_name" list="list_ackdepart1" type="text" name="ackdepart_name"   class="form-control" placeholder="Name"/>
									<datalist id="list_ackdepart1">
									
									</datalist>
							</div>
							 
							 <div class="col-sm-4"> 
							 		<label for="ackdepart_Position">Position :</label>
                                    <input id="ackdepart_Position" type="text" name="ackdepart_Position"   class="form-control" placeholder="Position"/>
							 </div>
							 
                             <div class="col-sm-4"> 
							 		<label for="ackdepart_department">Department :</label>
									<input id="appdepart_Position" type="text" name="appdepart_Position" required  class="form-control" placeholder="Department"/>
							 </div>
							
						  </div>
						  
						</div-->
					</div>
						
						<br>
						<label style="font-size:14px;"><b>Acknowledge  person</b></label>
						 
						<div class="row">  
							<div class="col-md-12">						
								  <label for=""style="font-size:14px;">Add amount of  concern :	
									  <img src="../assets/images/plus_blue.png" class = "add_field_button" style="width: 4%; height: 4%;"/>	
								  </label>        
							</div>
						</div>
						
						
					<div class="row" id="inputboxes">
                        <div class="col-md-12">
                          <div class="form-group row" id="group_ackdepart">
						  
							<!--input Concern  department -->
							 
						  </div>
						</div>
					</div>
		


						<br>
							
									<div class="row">
										<div class="col-md-12">
											<div class="form-group row">
													<div class="col-sm-6" > 
														<button  value="Upload" style ="background-color:#7eb73d; border-color:#7eb73d;" type="submit" class="btn btn-success btn-fw" "data-toggle="modal" data-target="#mydelete3">Submit</button>	
													</div>	
													<div class="col-sm-6" style="text-align: right;"> 											
														<button  style ="background-color:#c2161c; border-color:#c2161c; " type="button" class="btn btn-dark btn-fw">Cancel</button>
													</div>	
											</div>	
										</div>	
									</div>

									

									
		</form>							
				<!--				
						<form action="../ENG/smartsearch_pcr.php"" method="post">
							<input type="text" name="search">
							<input type="text" name="anuual_plan">
							<input type="submit" name="submit" value="Search">
						</form>								
				-->
								
                    </div>	
<!-- end form section 6 data-toggle="modal" 
										// data-target="#Input_PCR_Modal" -->    



	 </div>
	 
						 
			</div>
			</div> 
			</div>
				</div>
        </div>
			
	</div>

	</div>	
	   </div>
  </body>
  
  <style>
	html, body {
      min-height: 100%;
      }
   
    .data-attachments-input{
		border: 1px solid #ccc;
		font-family: "ubuntu-regular", sans-serif;
		font-size: 0.8125rem; 
		justify-content:space-around;
		width:65%;
		height:35px;
		padding: 12px 20px;
		margin: 8px 0;
		display: inline-block;
		border-radius: 2px;
		box-sizing: border-box;	
	}
	.data-attachments-input:focus {
    background-color: #ffffff;
    color: #000;
    outline: none; 
	}
     
    textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
    .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color:  #124373;
      }
    .item input:hover, .item select:hover, .item textarea:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 3px 0  #124373;
      color: #124373;
     }
     .item {
      position: relative;
      margin: 10px 0;
	  font-size: 14px;
      }
      
     
      .item i::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #00b33c;
      }
      .item i {
      right: 1%;
      top: 30px;
      z-index: 1;
      }
      
      .columns {
      display:flex;
      justify-content:space-around;
      flex-direction:row;
      flex-wrap:wrap;
      }
	   .columns2 {
      display:flex;
      justify-content:space-around;
      flex-direction:row;
      flex-wrap:wrap;
      }
      .columns div {
      width:40%;
      }
      
      .question span {
      margin-left: 30px;
      }
      .question-answer label {
      display: block;
      }
	  .col-md-12-radio{
		 height:50px;
	  }
    
</style>


<!--confirm button-->

	
		<!-- endinject -->
		<!-- Plugin js for this page -->
		<!-- End plugin js for this page -->
		<!-- inject:js -->
		<script src="../assets/js/form.js"></script>
	
		<script src="../assets/js/file-upload.js"></script>
		<script src="../assets/js/off-canvas.js"></script>
		<script src="../assets/js/hoverable-collapse.js"></script>
		<!-- endinject -->
		

		
	
 <style>
	.wrapper {
		text-align: right;
	}

	.button {
		position: absolute;
		top: 50%;
	}
	.centered {
	  position: absolute;
	  top: 30%;
	  left: 50%;
	  width: 100%;
	  transform: translate(-50%, -50%);
	}
	.headC{
	background-color: #124373;
	height: 45px
	}
	.remove_field{
		color:red;
	}
</style>
 <script>

$(document).ready(function(){
	$('#Select_Department_pcr').on('change',function(){
		var Select_Depart_ID = $(this).val();
		console.log(Select_Depart_ID);
			$.ajax({
				type:'POST',
				url:'../ENG/Ajax_Acknowledge_Approve.php',
				data:{Select_Depart_ID: Select_Depart_ID},
				success:function(html){
				console.log(html);
				//document.pcr.ackdepart_name_first.value = html;
				 document.getElementById("ackdepart_name_first").html = html;
				 $('#ackdepart_name_first').html(html);
				 //$('#ackdepart_name').html(html);
				}
			}); 			
	});
});	
</script>	

<script>

$(document).ready(function(){
		$('#anuual_Plan_No').on('change',function(){
		var anuual_ID = $(this).val();
		console.log(anuual_ID);
			$.ajax({
                type: 'POST',
                data: {anuual_ID: anuual_ID},
                url: '../ENG/Ajax_Anuual_Plan.php',
				dataType: "JSON",
                success: function(data) {
					console.log(data);
					document.pcr.title_pcr.value = data.Title;
					document.pcr.addition_item.value = data.Add_item;
					document.pcr.change_type.value = data.Change_type;
					document.pcr.rank.value = data.Rank;
					document.pcr.customer_submission.value = data.Customer_sub;
					document.pcr.planning_review.value = data.Plan_review;
					document.pcr.product.value = data.Product;
					document.pcr.part_name.value = data.P_name;
					document.pcr.change_point.value = data.Cp;
                }
            });
                    return false;
		
	});
});	
</script>
<script>

$(document).ready(function(){

	$('#appdepart_Final').on('change',function(){ //ยังไม่เสร็จ
		var Final_ID = $(this).val();
		console.log(Final_ID);
			$.ajax({
                type: 'POST',
                data: {Final_ID: Final_ID},
                url: '../ENG/Ajax_Final_Approve.php',
				dataType: "JSON",
                success: function(data1) {
					console.log(data1);
					document.pcr.appdepart_Pos.value = data1.position;
					//document.getElementById("appdepart_Pos").value = data1.position;
					document.pcr.appdepart_department.value = data1.section;
                }
            });
                    return false;
		
	});

});

$(document).ready(function() {
    var max_fields      = 5; //maximum input boxes allowed
    var wrapper         = $("#group_ackdepart"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID

    var x = 1; //initial text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
			   $(wrapper).append(
					'<div class="col-md-12"><div class="form-group row" id="group_app_department"><div class="col-sm-4"> <label for="appdepart_name">Name :</label><input id="appdepart_name[]" type="text" name="appdepart_name[]" required class="form-control" list="list_app" placeholder="Name"/><datalist id="list_app"><?$sqlperson = "SELECT *FROM employee WHERE Position_ID <= 'P524' AND Position_ID > 'P211' AND Statuswork_ID = 1";	$resultperson = mysqli_query($condbmc, $sqlperson);WHILE($rowperson = mysqli_fetch_array($resultperson)){?><option value-data="<?echo$rowperson["Emp_ID"]?>"> <?echo$rowperson[Empname_engTitle]." ".$rowperson["Empname_eng"]." ".$rowperson["Empsurname_eng"]?> </option><?}?></datalist></div><div class="col-sm-4"><label for="appdepart_Position">Position :</span></label><input id="appdepart_Position[]" type="text" name="appdepart_Position[]" required class="form-control" placeholder="Position"/></div> <div class="col-sm-4"> <label for="appdepart_department">Department :</label><input id="appdepart_department[]" type="text" name="appdepart_department[]" required class="form-control" placeholder="Department"/></div><a href="#" class="remove_field">Remove</a></div></div>'
				);
        }
    });

    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});


</script>
<script>

$(document).ready(function() {
    var max_fields      = 5; //maximum input boxes allowed
    var wrapper         = $("#group_app_department"); //Fields wrapper
    var add_button      = $(".button_department"); //Add button ID

    var x = 1; //initial text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
				$(wrapper).append(
					'<div class="col-md-12"><div class="form-group row" id="group_app_department"><div class="col-sm-4"> <label for="appdepart_name">Name :</label><input id="appdepart_name[]" type="text" name="appdepart_name[]" required class="form-control" list="list_app" placeholder="Name"/><datalist id="list_app"><?$sqlemp = "SELECT * FROM employee WHERE Emp_ID = '".$_SESSION['empid_pcr']."'";$resultemp = mysqli_query($condbmc, $sqlemp);$rowemp = mysqli_fetch_array($resultemp);$sqlsec = "SELECT * FROM sectioncode WHERE Sectioncode = '".$rowemp['Sectioncode_ID']."'";	$resultsec = mysqli_query($condbmc, $sqlsec);$rowsec = mysqli_fetch_array($resultsec);$sqlgroup = "SELECT * FROM sectioncode WHERE group_id = '".$rowsec['group_id']."'";$resultgroup = mysqli_query($condbmc, $sqlgroup);WHILE($rowgroup = mysqli_fetch_array($resultgroup)){$sqlapp = "SELECT *FROM employee WHERE Sectioncode_ID = '".$rowgroup['Sectioncode']."' AND Position_ID < '".$_SESSION['postid_pcr']."' AND  Position_ID <= 'P514' AND Position_ID > 'P221' AND Statuswork_ID = 1";	$resultapp = mysqli_query($condbmc, $sqlapp);WHILE($rowapp = mysqli_fetch_array($resultapp)){?><option value-data="<?echo$rowapp["Emp_ID"]?>"> <?echo$rowapp[Empname_engTitle]." ".$rowapp["Empname_eng"]." ".$rowapp["Empsurname_eng"]?> </option><?}}?></datalist></div><div class="col-sm-4"><label for="appdepart_Position">Position :</span></label><input id="appdepart_Position[]" type="text" name="appdepart_Position[]" required class="form-control" placeholder="Position"/></div> <div class="col-sm-4"> <label for="appdepart_department">Department :</label><input id="appdepart_department[]" type="text" name="appdepart_department[]" required class="form-control" placeholder="Department"/></div><a href="#" class="remove_field">Remove</a></div></div>'
				); //add input box
        }
    });

    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});


$("*").each( function () {
    var $this = $(this);
    if (parseInt($this.css("fontSize")) < 15) {
        $this.css({ "font-size": "14px" });		
    }
});

</script>
<script>
$(document).ready(function() {
	$("#check_PFMEA").function(){
	if (document.getElementById("check_PFMEA").checked == true){
		document.getElementById("check_PFMEA").value = 1;
  } else {
    document.getElementById("check_PFMEA").value = null;
  }
	}

	$("#check_qa_network").function(){
	if (document.getElementById("check_qa_network").checked == true){
		document.getElementById("check_qa_network").value = 1;
  } else {
    document.getElementById("check_qa_network").value = null;
  }
	}

	$("#check_control_plan").function(){
	if (document.getElementById("check_control_plan").checked == true){
		document.getElementById("check_control_plan").value = 1;
  } else {
    document.getElementById("check_control_plan").value = null;
  }
	}
	$("#standardize").function(){
	if (document.getElementById("standardize").checked == true){
		document.getElementById("standardize").value = 1;
  } else {
    document.getElementById("standardize").value = null;
  }
	}
	$("#machine_sprci").function(){
	if (document.getElementById("machine_sprci").checked == true){
		document.getElementById("machine_sprci").value = 1;
  } else {
    document.getElementById("machine_sprci").value = null;
  }
	}
	$("#daily_check").function(){
	if (document.getElementById("daily_check").checked == true){
		document.getElementById("daily_check").value = 1;
  } else {
    document.getElementById("daily_check").value = null;
  }
	}
	$("#other").function(){
	if (document.getElementById("other").checked == true){
		document.getElementById("other").value = 1;
  } else {
    document.getElementById("other").value = null;
  }
	}
  
  
});
</script>

  
</html>