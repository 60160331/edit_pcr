<?php
date_default_timezone_set('asia/bangkok');
include "../ENG/connectpcr.php";
include "../ENG/connectdbmc.php";
session_start();
$k =1;
$sql = "SELECT pro_name,fm_pcr_number,anp_part_name,anp_title,rk_name,anp_cus_sub,fm_state_app,fm_usr_emp_code,fm_pcr_leadtime,fm_create_date  FROM `pcr_form` LEFT JOIN pcr_annual_plan on pcr_form.fm_anp_id = pcr_annual_plan.anp_anp_number LEFT JOIN pcr_section_anp on pcr_annual_plan.`anp_sec_id` = pcr_section_anp.sec_id   
LEFT JOIN pcr_change_type on pcr_annual_plan.`anp_ct_id` = pcr_change_type.ct_id LEFT JOIN pcr_change_point on pcr_annual_plan.anp_cp_id = pcr_change_point.cp_id 
LEFT JOIN pcr_product ON pcr_annual_plan.anp_pro_id = pcr_product.pro_id LEFT JOIN pcr_rank ON pcr_annual_plan.anp_rk_id = pcr_rank.rk_id WHERE fm_usr_emp_code = '".$_SESSION["emp_id"]."'";

    //$query = mysqli_query($sql);
    //$row = $query->fetch_assoc();
    //$rowsec = mysqli_fetch_array($query);
    //$lead =$rowsec["fm_pcr_leadtime"];


?>

<!DOCTYPE html>
<html lang="en">

	<head>

	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" />
	   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

  <link href="assets/css/fresh-bootstrap-table.css" rel="stylesheet" />

  <!-- Fonts and icons -->
  <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/demo_1/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png">
  </head>

  <body>
  <script>
  $(document).ready(function() {
    $('#example').DataTable();
} );

  </script>

 
  <div class="container-scroller">
<!------------------------------------------------ Header templete ------------------------------------------------>
	<?php include("Navbar_pcr.php")?>
  
  <!------------------------------------------------ Header templete ------------------------------------------------>



	<div class="container-fluid page-body-wrapper">
	<?php
    include("header_creator.php")?>
		<!--space header-->
	    <div class="main-panel">
          <div class="content-wrapper">

			<!--space header-->
		
	
			  <div class="card-header headC">
					<center style="color:white;"><h4><b>MY PCR FORM</b><h4></center>
			  </div>
			 <div class="card">
			 <br>
			<a class="nav-link" href="#">
                <button style ="background-color:#fc5226; border-color:#fc5226;" class="btn btn-md btn-success" onclick="window.location.href='IN0001.php';">+ Process Change</button></a>
    <div class="card-body">
			
			   <form class="forms-sample">
			       <div class="data-table-area">

					<div class="table-responsive">
						<table id="example" class="table table-hover ">
						<thead>
							
						<tr>
							<th><center> No</center></th>
							<th><center> PCR number </center></th>
							<th><center> Title</center> </th>
                            <th><center> Product name </center></th>
							
							<th><center> Date </center></th>					
							<th><center> Action </center> </th>
                        </tr>	
                      </thead>
					  <?php
                        $query = mysqli_query($conn, $sql);
                        while ($pcr = mysqli_fetch_array($query)) {
                            // echo $rowview['Empname_engTitle']." ".$rowview['Empname_eng']." ".$rowview['Empsurname_eng'];?>	  
					  <?php $i = 1; ?>
						  <tbody>

						<tr>
							<td> <center>1</center></td>
							<td><center><?php echo $pcr['fm_pcr_number']; ?></center></td>
							<td><center><?php echo $pcr['anp_title']; ?></center> </td>
                            <td><center><?php echo $pcr['pro_name']; ?></center></td>
							
							<td><center>01/07/2020</center></td>                      
							<center><td><center>
							<button style ="background-color:#00bcd4; border-color:#00bcd4;" type="button" class="btn btn-sm btn-success" onclick="window.location.href='CT0002.php';">
							<img src="../assets/images/button/search.svg" class = "icon"/></button>
							<button type="button"style ="background-color:#ecb100; border-color:#ecb100;" class="btn btn-sm btn-danger" onclick="window.location.href='IN0003.php?pcr_number=<?php echo $pcr['fm_pcr_number']?>'"><img src="../assets/images/button/pencil.svg" class = "icon" /></button>
							<button type="button"style ="background-color:#5b5b5b; border-color:#5b5b5b;" class="btn btn-sm btn-danger" onclick="window.location.href='CT0004.php';"><img src="../assets/images/button/status.svg" class = "icon" /></button>
							<button type="button"style ="background-color:#c2161c; border-color:#c2161c;" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#Upload_DAR_Modal"><img src="../assets/images/button/delete.svg" class = "icon" /></button>
							</center></td></center>
                        </tr>
						<?php
                    $i = $i+1 ;
                        }
                    ?>
                  
							  </tbody>
							</table>													
							</div>
						
                 
			
</div>
<form>
			
			</div>
				
	
               
		
<!---->
              </div>
            </div>
			
	</div>

	</div>	
	   </div>
	  

  </body>
  
  <style>
.headC{
	background-color:#124373;
	height: 45px;
}
button.one {
	background-color: #4CAF50;
	font-size: 10px;
	}
.icon{
	max-height: 15px;
max-width: 25px;
width: 15px;
height: 25px;
}
}
</style>



<!--Data table -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/bootstrap-table/dist/bootstrap-table.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>


<!---------------Modal Upload DAR Form -------->
 <div class="modal fade" id="Upload_DAR_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
						<center>
							
						</center>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
			    </div>
			<div class="modal-body">
					
				<div class="card">
								<div class="card-header headC">
									<center style="color:white;"><h4><b>Upload file DAR</b><h4></center>
								</div>
					<div class="card-body"> 
									<form class="form-sample"> <!-- Form input BKD-->  
									
									<div class="form-group">
										<label>No.PCR</label>
										<!--<h4 class="card-title">No.PCR</h4>-->
										<input class="form-control" id="" type="text" name="" />
									</div>
									
									<div class="form-group">
									
										
										<label>File upload DAR</label>
											<input type="file" name="img[]" class="file-upload-default">
										<div class="input-group col-xs-12">
											<input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
												<span class="input-group-append">
													<button class="file-upload-browse btn btn-gradient-primary" type="button" 
													style="backgroundr:#ffffff;">Upload
													</button>
												</span>
										</div>
										
									</div>          
									</form>
									
						</div>
					</div>
									
					
			</div>
				<div class="modal-footer justify-content-between">
					<button style ="background-color:#7eb73d; border-color:#7eb73d;" type="button" class="btn btn-danger">Submit</button>
					<button style ="background-color:#c2161c ; border-color:#c2161c ;"type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
			  </div>
		</div>
	</div>

<!---------------Modal Upload DAR Form -------->
<!--confirm button-->
<style>
/*confirm button*/
body {
	font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 400px;
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
<!--confirm button-->
</style>

  
</html>