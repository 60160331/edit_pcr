<?php
    include("connectpcr.php");
    include("connectdbmc.php");
    $formID = "SELECT pf.fp_fm_id AS fm_id FROM pcr_form_priority as pf INNER JOIN pcr_form as fm on pf.fp_fm_id = fm.fm_id INNER JOIN pcr_priority AS pri ON pf.fp_pri_id = pri.pri_id WHERE fm.fm_pcr_number ='".$_POST["pcr_number"]."'";
    $fm = $conn->query($formID);
    $fm_id = $fm->fetch_assoc();
     $formid = $fm_id["fm_id"];


     $pcr_num =$_POST["pcr_number"];
     $leatime = $_POST["normal_urgent"];
     $flowout =  $_POST["Part_test_flow_out"];
     $quality  = $_POST["quality"];
     $safety = $_POST["safety"];
     $delivery = $_POST["delivery"];
    echo "<br>";

    //attach doc start
    $pf= "UPDATE pcr_attach_doc SET att_pfmea = '".$_POST["check_PFMEA"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $pfmea = $conn->query($pf);
    
    $qanet= "UPDATE pcr_attach_doc SET att_qa_network = '".$_POST["check_qa_network"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $network = $conn->query($qanet);
    
    $ctplan= "UPDATE pcr_attach_doc SET att_control_plan = '".$_POST["check_control_plan"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $ctp= $conn->query($ctplan);
    
    $standard= "UPDATE pcr_attach_doc SET att_wi = '".$_POST["standardize"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $std = $conn->query($standard);
    
    $machinespec= "UPDATE pcr_attach_doc SET att_machine_spec = '".$_POST["machine_sprci"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $machine = $conn->query($machinespec);
    
    $daily= "UPDATE pcr_attach_doc SET att_daily_check = '".$_POST["daily_check"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $dai = $conn->query($daily);
    
    $other= "UPDATE pcr_attach_doc SET att_other = '".$_POST["other"]."' WHERE att_id = '".$fm_id["fm_id"]."'";
    $oth = $conn->query($other);
    //attach doc end
    
    //detail check and part number start
    $lt= "UPDATE pcr_form SET fm_pcr_leadtime = '$leatime' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $lead_time = $conn->query($lt);

    $qual= "UPDATE pcr_form SET fm_quality = '$quality' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $qua = $conn->query($qual);
    
    $safe= "UPDATE pcr_form SET fm_safety = '$safety' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $saf = $conn->query($safe);
    
    $deliv= "UPDATE pcr_form SET fm_delivery = '$delivery' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $deli = $conn->query($deliv);
    
    $flowo = "UPDATE pcr_form SET fm_flowout= '$flowout' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $flow = $conn->query($flowo);
    
    $partnumber = $_POST["part_number"];
    $numpart = "UPDATE pcr_form SET fm_part_number = '$partnumber' WHERE fm_pcr_number = '".$_POST["pcr_number"]."'";
    $partnum= $conn->query($numpart);
    //detail check and part number end
   
    //IMPLEMENT PLAN START
    $implement1 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["pcr_plan_sub_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 1";
    $imp1 = $conn->query($implement1);
    
    $implement2 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["plan_review_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 2";
    $imp2 = $conn->query($implement2);
    
    $implement3 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["pro_preparation_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 3";
    $imp3 = $conn->query($implement3);
    
    $implement4 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["product_evaluation_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 4";
    $imp4 = $conn->query($implement4);
    
    $implement5 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["revise_doc_stadart_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 5";
    $imp5 = $conn->query($implement5);
    
    $implement6 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["six_report_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 6";
    $imp6 = $conn->query($implement6);
    
    $implement7 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["pcr_result_sum_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 7";
    $imp7 = $conn->query($implement7);
    
    $implement8 = "UPDATE pcr_implement_form SET mf_date_plan = '".$_POST["product_start_date_plan"]."' WHERE mf_fm_id = '".$fm_id["fm_id"]."' AND mf_im_id = 8";
    $imp8 = $conn->query($implement8);
    //IMPLEMENT PLAN END

    
//SC POINT START
     $sc = $_POST["sc"];
     $delsc = "DELETE FROM pcr_form_priority AS pr WHERE pr.fp_fm_id = '".$fm_id["fm_id"]."'";
     $queryscdel = $conn->query($delsc);
    foreach ($sc as $val) {
        $sql = "INSERT INTO pcr_form_priority(fp_fm_id, fp_pri_id) 
		VALUES ('$formid','$val')";
        $query = $conn->query($sql);
    }
    //SC POINT END
    

?>

