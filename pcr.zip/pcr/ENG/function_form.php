<?php
session_start();
include "connectpcr.php";
include "connectdbmc.php";
    function Anuualplan($conn)
    {
        $sqlann = "SELECT * FROM pcr_annual_plan";
        $resultann = mysqli_query($conn, $sqlann);
        while ($rowann = mysqli_fetch_array($resultann)) {
            echo "<option data-value='" . $rowann['anp_anp_number'] . "'>" . $rowann['anp_anp_number'] . "</option>";
        }
    }
    
    function appdepart_Final($condbmc)
    {
        $sqlemp = "SELECT * FROM employee WHERE Emp_ID = '".$_SESSION["empid_pcr"]."'";
        $resultemp = mysqli_query($condbmc, $sqlemp);
        $rowemp = mysqli_fetch_array($resultemp);
        $sqlsec = "SELECT * FROM sectioncode WHERE Sectioncode = '".$rowemp["Sectioncode_ID"]."'";
        $resultsec = mysqli_query($condbmc, $sqlsec);
        $rowsec = mysqli_fetch_array($resultsec);
        $sqlgroup = "SELECT * FROM sectioncode WHERE group_id = '".$rowsec["group_id"]."'";
        $resultgroup = mysqli_query($condbmc, $sqlgroup);
        while ($rowgroup = mysqli_fetch_array($resultgroup)) {
            $sqlapp = "SELECT *FROM employee WHERE Sectioncode_ID = '".$rowgroup["Sectioncode"]."' AND Position_ID <= 'P211' AND Position_ID > 'P101'  AND Statuswork_ID = 1";
            $resultapp = mysqli_query($condbmc, $sqlapp);
            while ($rowapp = mysqli_fetch_array($resultapp)) {
                echo "<option value='" . $rowapp['Emp_ID'] . "'>"  . $rowapp['Empname_engTitle']." ".$rowapp['Empname_eng']." ".$rowapp['Empsurname_eng'] . "</option>";
            }
        }
    }
    
    function appdepart_acknowledge($condbmc)
    {
        $sqlacp = "SELECT *FROM employee WHERE Position_ID <= 'P413' AND Position_ID > 'P302'  AND Statuswork_ID = 1 AND Company_ID= '".$_SESSION["companyid_pcr"]."'";
        $resultapp = mysqli_query($condbmc, $sqlacp);
        while ($rowacp = mysqli_fetch_array($resultacp)) {
            echo "<option value='" . $rowacp['Emp_ID'] . "'>"  . $rowacp['Empname_engTitle']." ".$rowacp['Empname_eng']." ".$rowacp['Empsurname_eng'] . "</option>";
        }
    }
    // function appdepart_department($condbmc)
    // {
        // $sqlapp = "SELECT *FROM employee WHERE Position_ID <= 'P413' AND Position_ID > 'P302'  AND Statuswork_ID = 1 AND Company_ID= '".$_SESSION["companyid_pcr"]."'";
        // $resultapp = mysqli_query($condbmc, $sqlapp);
        // WHILE($rowapp = mysqli_fetch_array($resultapp)){
            // echo "<option value='" . $rowapp['Emp_ID'] . "'>"  . $rowapp['Empname_engTitle']." ".$rowapp['Empname_eng']." ".$rowapp['Empsurname_eng'] . "</option>";
        // }
        
    // }
?>
	