<?php
$servername = "localhost";
$username = "root";
$password = "kit60160331";
$dbname = "dbmc";


$condbmc = new mysqli($servername, $username, $password, $dbname);

if ($condbmc->connect_error) {
    die("Connection failed: " . $condbmc->connect_error);
}
