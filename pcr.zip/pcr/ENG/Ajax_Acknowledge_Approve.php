<?php
	include 'connectdbmc.php'; 
	session_start();
	// $Select_Depart_ID = $_POST["Select_Depart_ID"];
	// $sqlsec = "SELECT * FROM sectioncode WHERE dep_id = '".$Select_Depart_ID."'";	
	// $resultsec = mysqli_query($condbmc, $sqlsec);
	// while($rowsec = mysqli_fetch_array($resultsec)){
		// $sqlapp = "SELECT *FROM employee WHERE Sectioncode_ID = '".$rowsec["Sectioncode"]."' AND Position_ID <= 'P503' AND Position_ID > 'P302'  AND Statuswork_ID = 1";	
		// $resultapp = mysqli_query($condbmc, $sqlapp);
		// WHILE($rowapp = mysqli_fetch_array($resultapp)){
			// echo "<option value='" . $rowapp['Emp_ID'] . "'>"  . $rowapp['Empname_engTitle']." ".$rowapp['Empname_eng']." ".$rowapp['Empsurname_eng'] . "</option>";
		// }
	// }
	

	$Acknowledge_ID = $_POST["Acknowledge_ID"];
	echo $Acknowledge_ID;
	$sql = "SELECT * FROM employee WHERE Emp_ID = '".$Acknowledge_ID."'";
	$query = $condbmc->query($sql);
	$row = $query->fetch_assoc();
	$sqlpos = "SELECT * FROM position WHERE Position_ID = '".$row["Position_ID"]."'";
	$querypos = $condbmc->query($sqlpos);
	$rowpos = $querypos->fetch_assoc();
	$sqlsec = "SELECT * FROM sectioncode WHERE Sectioncode = '".$row["Sectioncode_ID"]."'";
	$querysec = $condbmc->query($sqlsec);
	$rowsec = $querysec->fetch_assoc();
		
		$data3 = array(
				"position_ac"   => $rowpos["Position_name"],
				"section_ac"  	 => $rowsec["Department"],
				
		);
	echo json_encode($data3);
	
	
		
	
?>