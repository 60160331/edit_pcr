<?
include "connectpcr.php";
include "connectdbmc.php";
$empid = $_POST["empid"];
$email = $_POST["email"];
date_default_timezone_set('asia/bangkok');
session_start();
$sqluser = "SELECT * FROM pcr_user WHERE usr_emp_code = '".$empid."'  ";
$queryuser = $conn->query($sqluser);
if($rowuser = $queryuser->fetch_assoc()){
	echo "<script language=\"JavaScript\">";
	echo "alert('This employee ID has already been registered.')";
	echo "</script>";
	echo '<meta http-equiv=refresh content=0;URL=../index.php>';
}else{
	$sql = "SELECT * FROM email WHERE EmpID = '".$empid."'  ";
	$query = $condbmc->query($sql);
	if($row = $query->fetch_assoc()){
		if($row["mail"] == $email){
			include("random_password.php");
			
			$date = date("Y-m-d",strtotime('+180 day'));
			$sqlin = "INSERT INTO pcr_user (usr_emp_code,usr_exp_date) VALUES ('".$empid."','".$date."')  ";
			if($queryin = $conn->query($sqlin)){
				echo "<script language=\"JavaScript\">";
				echo "alert('Waiting for PE Admin Approval')";
				echo "</script>";
				echo '<meta http-equiv=refresh content=0;URL=../index.php>';	
		
			}else{
				echo "<script language=\"JavaScript\">";
				echo "alert('Register Error')";
				echo "</script>";
				echo '<meta http-equiv=refresh content=0;URL=../index.php>';	
			}
			
		}else{
			echo "<script language=\"JavaScript\">";
			echo "alert('Invalid email address')";
			echo "</script>";
			echo '<meta http-equiv=refresh content=0;URL=../index.php>';
		}
	}else{
		echo "<script language=\"JavaScript\">";
		echo "alert('Invalid ID Employee')";
		echo "</script>";
		echo '<meta http-equiv=refresh content=0;URL=../index.php>';
	}
}





// ini_set("SMTP","10.72.220.5");
					// ini_set("port","25");
					// $email = $row["mail"];
					// $strTo = $email;
					// $hris = "http://sdm148020/PCR-2019";
					// $strSubject = "Process Change Report Managements System";
					// $strHeader = "Content-type: text/html; charset=UTF-8\r\n"; // or UTF-8 //
					// $strVar = "My Message";
					// $headers =  'MIME-Version: 1.0' . "\r\n"; 
					// $headers .= 'From: "PCR System" <hris.information.a9z@ap.denso.com>' . "\r\n";
					// $headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n"; 
					// $strMessage = "
						// <hr>
						// <h4>PCR System : Password</h4>
						// <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your registration in E-PCR System completed successfully.</p>
						// <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your password is <b><u><font color = red>".$passw."</font></u></b></p>
						// <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LINK ---->  <b><u><font color = red><a href = ".$hris.">Click here</a></font></u></b></p>
						// <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please keep your password.</p>
						// <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thank you.</p>
						// <br>
						// <br>
						// <br>
						// <p> ---------------------------------- </p>
						// <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; If you encounter problems, please contact us. </p>
						// <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tel : 2534,2550  </p>
						// <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Email : hris.information.a9z@ap.denso.com </p>
					// ";

					// $flgSend = mail($strTo,$strSubject,$strMessage,$headers);  // @ = No Show Error //
					// if($flgSend){
						// echo "<script language=\"JavaScript\">";
						// echo "alert('Password has been send by email.');";
						// echo "</script>";
						// echo '<meta http-equiv=refresh content=0;URL=../index.php>';
					// }else{
						// echo "<script language=\"JavaScript\">";
						// echo "alert('Can not send mail Please check the validity of the email address.');";
						// echo "</script>";
						// echo '<meta http-equiv=refresh content=0;URL=../index.php>';
					// }







































// $sql = "SELECT * FROM pcr_user WHERE usr_emp_code = '".$empid."'";
// $query = $conn->query($sql);
// if($objResult = $query->fetch_assoc()){
	// if($objResult["usr_sr_id"] == 1 ){
		// echo "<script language=\"JavaScript\">";
		// echo "alert('มีรหัสอยู่แล้ว')";
		// echo "</script>";
		// echo '<meta http-equiv=refresh content=0;URL=../INT/login.php>';
	// }else if($objResult["usr_sr_id"] == 2 ){
		// $sqlemp = "SELECT * FROM employee WHERE Emp_ID = '".$empid."'";
		// $queryemp = $condbmc->query($sqlemp);
		// if($rowemp = $queryemp->fetch_assoc()){
			// $sqlemail = "SELECT * FROM email WHERE EmpID = '".$empid."'";
			// $queryemail = $condbmc->query($sqlemail);
			// $rowemail = $queryemail->fetch_assoc()
			// if($rowemail["mail"] == $email){
				
			// }else{
				// echo "<script language=\"JavaScript\">";
				// echo "alert('อีเมลผิด')";
				// echo "</script>";
				// echo '<meta http-equiv=refresh content=0;URL=../INT/login.php>';
			// }
		// }else{
			// echo "<script language=\"JavaScript\">";
			// echo "alert('ไม่มีข้อมูลพนักงาน')";
			// echo "</script>";
			// echo '<meta http-equiv=refresh content=0;URL=../INT/login.php>';
		// }
		
		
	// }else if($objResult["usr_sr_id"] == 3 ){
		// echo "<script language=\"JavaScript\">";
		// echo "alert('รออนุมัติ')";
		// echo "</script>";
		// echo '<meta http-equiv=refresh content=0;URL=../INT/login.php>';
	// }
// }else{
	
// }

?>